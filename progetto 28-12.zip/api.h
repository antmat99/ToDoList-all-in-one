#ifndef API_H
#define API_H

#include <curl/curl.h>
#include <curlpp/cURLpp.hpp>
#include <curlpp/Easy.hpp>
#include <curlpp/Options.hpp>
#include <sstream> //per ostringstream
#include <vector>
#include "network.h"
#include "parser.h"
#include <QObject>
#include <iostream>

using namespace curlpp::options;

/*
Basata su singleton. Alla prima costruzione si fa la post per ottenere i valori (auth code, ecc)

Patter State per capire quale signal emettere una volta arrivata la risposta da network

TODO:   - prima di ogni chiamata bisognerebbe chiamare una funzione che eventualmente si occupi
        del refresh del token

        - distruttore
*/


class API : public QObject {
    Q_OBJECT
public:
    //alla prima chiamata di getInstance dovrò passare t_code per la post nel costruttore, alle altre non passo niente
    static API* getInstance(std::string t_code=nullptr);
    /* Funzioni sui calendari */
    void getCalendars(); //senza parametri perché l'utente si capisce con l'auth code nella richiesta
    void insertCalendar(); //senza parametri perché l'utente si capisce con l'auth code nella richiesta
    void deleteCalendar(std::string calendar_id);
    void shareCalendar(std::string calendar_id);
    /* Funzioni sugli eventi */
    void getEventsByCalendarDay(std::string calendar_id, std::string date);
    void insertEvent(std::string calendar_id, std::string description, std::string begin_date, std::string endDate); //TODO ritorna l'id dell'evento?
    void deleteEvent(std::string calendar_id, std::string event_id);
    void updateEventDescription(std::string calendar_id, std::string event_id, std::string new_description);
    void updateEventStartDate(std::string calendar_id, std::string event_id, std::string start_date);

/*
Gli slot catturano i signal emessi da network e a loro volta emettono signal che verranno
presi dai componenti della gui
*/
public slots:
    void responseSlot(std::string response);

/*
I signal emessi da API verranno presi dalla gui per mostrare a schermo i risultati
*/
signals:
    //fare un signal per ogni valore della enum ResultType
    void signalCalendar(Calendar* calendar);
    void signalCalendarList(std::vector<Calendar*> calendarList);
    void signalEvent(Event* event);
    void signalEventList(std::vector<Event*> eventList);

private:
    static API *instance;

    enum ResultType {CALENDAR_LIST, CALENDAR, EVENT_LIST, EVENT, EMPTY};
    ResultType resultType;

    std::string a_code;
    std::string r_token;
    std::string exp_in;
    Network *network;
    Parser *parser;

    API(std::string t_code,QObject *parent = 0); //costruttore privato
    std::vector<std::string> split(std::string s, std::string delimiter);

    void returnCalendarList(std::string response);
    void returnCalendar(std::string response);
    void returnEventList(std::string response);
    void returnEvent(std::string response);

};

#endif // API_H
