#ifndef MYNETWORK_H
#define MYNETWORK_H

#include <QObject>
#include <iostream>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include "mainwindow.h"

class MyNetwork : public QObject
{
    Q_OBJECT
public:
    explicit MyNetwork(QObject *parent = 0);
    void makeGetRequest(QString endpoint);
    void makePostRequest(QString endpoint, QByteArray postData);
    std::string readResponse(QNetworkReply *reply);
    void setWindow(MainWindow *w);
    void setCode(std::string a_code);

signals:
    void dataReadyRead(QByteArray);

public slots:
    void readRead(QNetworkReply *reply);
    void miaomiao();

private:
    QNetworkAccessManager *manager=new QNetworkAccessManager(this);
    MainWindow *w;
    std::string a_code;


};

#endif // MYNETWORK_H
