#include "mainwindow.h"

int c = 0;

MainWindow::MainWindow(QWidget *parent)
    : QWidget(parent),
      ui(new Ui::MainWindow)
{

    createPreviewGroupBox();
    createGeneralOptionsGroupBox();
    createTextFormatsGroupBox();
    textEdit = new QTextEdit();
    layout = new QGridLayout;
    layout->addWidget(previewGroupBox, 0, 0);
    layout->addWidget(textEdit,0,1) ;
    textEdit->setReadOnly(true);
    //textEdit->setEnabled(false);

    QPushButton *button2 = new QPushButton("Preferenze Calendario");
    button22 = new QPushButton("Nascondi Preferenze");
    QPushButton *button3 = new QPushButton("Get Calendari");
    //layout->addWidget(textFormatsGroupBox, 1,2);

    layout->addWidget(button2, 2,1);
    layout->addWidget(button3, 1,1);
    layout->setSizeConstraint(QLayout::SetFixedSize);
    setLayout(layout);

    previewLayout->setRowMinimumHeight(1, calendar->sizeHint().height());
    previewLayout->setColumnMinimumWidth(0, calendar->sizeHint().width());


    setWindowTitle(tr("Calendar Widget"));
    api = API::getInstance("");
    connect(button2, SIGNAL(clicked()), this, SLOT(showPreferences()) );
    connect(button22, SIGNAL(clicked()), this, SLOT(hidePreferences()) );
    connect(button3, SIGNAL(clicked()), this, SLOT(miao()));
    connect(api, SIGNAL(signalCalendarList(std::vector<Calendar*>)), this, SLOT(showCalendars(std::vector<Calendar*>)));
    connect(api, SIGNAL(signalEventList(std::vector<Event*>)),this,SLOT(showEvents(std::vector<Event*>)));
    connect(api, SIGNAL(signalToDoList(std::vector<Event*>)), this, SLOT(showToDos(std::vector<Event*>)));
    //calendarList->setCurrentIndex(0);
}
//! [0]

void MainWindow::getEventsByDay(){

    QDate data = calendar->selectedDate();
    //costruisco la data che mi serve, con formato YYYY-MM-DDTHH:MM:SSZ
    std::string giorno = std::to_string(data.day());
    std::string mese = std::to_string(data.month());
    std::string anno = std::to_string(data.year());
    std::string timeMin = anno+"-"+mese+"-"+giorno+"T00:00:01Z";
    std::string timeMax = anno+"-"+mese+"-"+giorno+"T23:59:59Z";

    std::cout<<"call getEventsByCalendarDay"<<std::endl;
    //qua deve essere fatta la get agli eventi
    api->getEventsByCalendarDay(calendarTmp->getId(),timeMin,timeMax);

}

void MainWindow::getToDos(){
    std::cout<<"Getting todos . . ."<<std::endl;
    api->getToDos(calendarTmp->getId());
}

void MainWindow::hidePreferences(){
    generalOptionsGroupBox->hide();
    button22->hide();
}
void MainWindow::showPreferences(){
    generalOptionsGroupBox->show();
    button22->show();
    layout->addWidget(generalOptionsGroupBox, 0, 5);
    layout->addWidget(button22, 2,1);

}
void MainWindow::showCalendars(std::vector<Calendar *> ret){
    //salvo l'elenco di calendari in una variabile
    calendari = ret;
    for(int i = 0; i<ret.size(); i++){
        std::cout<<ret.at(i)->toString()<<"\n"<<std::endl;
    }
    //GESTIONE MENU A TENDINA
    calendarList = new QComboBox;
    for(auto el : ret){
        calendarList->addItem(tr(el->getSummary().c_str()));
    }
    layout->addWidget(calendarList,2,0);
    calendarTmp=ret.at(0);
    api->getToDos(calendarTmp->getId());
    connect(calendarList, &QComboBox::currentIndexChanged, this, &MainWindow::selectCalendarTitle);

}

void MainWindow::showToDos(std::vector<Event *> ret){
    toDos = ret;
    if(toDos.size()!=0){
        toDoTmp = ret.at(0);
    }
    QTextEdit *textEdit2 = new QTextEdit();
    toDoList = new QComboBox;
    for(auto x : ret){
        textEdit2->append(x->getSummary().c_str());
        toDoList->addItem(tr(x->getSummary().c_str()));
    }
    layout->addWidget(toDoList,1,3);
    layout->addWidget(textEdit2,0,3);
    connect(toDoList,SIGNAL(currentIndexChanged(int)), this, SLOT(impostaNomeTodo(int)));
}

void MainWindow::impostaNomeTodo(int index){
    int c = 0;
    for(auto x : toDos){
        if(c==index){
            toDoTmp = x;
            break;
        }
        c++;
    }
    modalToDo();
}

void MainWindow::modalToDo(){
    QPushButton *mod = new QPushButton("modificami");
    QPushButton *hid = new QPushButton("Nascondi info");
    QPushButton *del = new QPushButton("eliminami");

    QGridLayout *l3 = new QGridLayout;
    layout->addLayout(l3,0,4);
    QLabel *starting = new QLabel("Info: ");
    QLabel *nomeE = new QLabel("Nome toDo: ");
    QLabel *titoloToDo = new QLabel();
    titoloToDo->setText(toDoTmp->getSummary().c_str());

    l3->addWidget(starting);
    l3->addWidget(nomeE);
    l3->addWidget(titoloToDo);
    l3->addWidget(hid);
    l3->addWidget(mod);
    l3->addWidget(del);

    connect(mod,SIGNAL(clicked()), this, SLOT(modToDo()));
    connect(del, SIGNAL(clicked()), this, SLOT(deleteToDo()));
    connect(hid, SIGNAL(clicked()), this, SLOT(nascondiInfoToDo()));
}

void MainWindow::deleteToDo(){
    std::cout<<"removing toDo..."<<std::endl;
    api->deleteToDo(calendarTmp->getId(),toDoTmp->getId());
}

void MainWindow::modToDo(){
    QGridLayout *layEditToDo = new QGridLayout;
    toDoEditName = new QTextEdit();
    QLabel *t = new QLabel();
    t->setText("Nome toDo:");
    toDoEditName->setFixedHeight(35);
    toDoEditName->setText(toDoTmp->getSummary().c_str());
    QPushButton *salvaMod = new QPushButton("Salva Modifiche");
    layEditToDo->addWidget(t);
    layEditToDo->addWidget(toDoEditName);
    layout->addLayout(layEditToDo,4,3);
    layout->addWidget(salvaMod,4,4);

    connect(salvaMod, SIGNAL(clicked()), this, SLOT(updateToDo()));
}

void MainWindow::updateToDo(){
    std::cout<<"started aggiornamento toDo"<<std::endl;
    api->updateToDo(calendarTmp->getId(), toDoTmp->getId(), toDoEditName->toPlainText().toStdString());
}

void MainWindow::nascondiInfoToDo(){

}

void MainWindow::showEvents(std::vector<Event *> ret){
    eventi = ret;
    textEdit->clear();
    eventList = new QComboBox;
    for( int i = 0;i<ret.size();i++){
        eventList->addItem(tr(ret.at(i)->getSummary().c_str()));
        textEdit->append("Titolo Evento: ");
        textEdit->append( ret.at(i)->getSummary().c_str() );
        textEdit->append("\n");

    }
    layout->addWidget(eventList,1,0);
    connect(eventList,SIGNAL(currentIndexChanged(int)), this, SLOT(selectEventTitle(int)));

    QPushButton *sel = new QPushButton("Aggiungi task/todo");
    QMenu *menu = new QMenu(this);
    QAction *at = new QAction(tr("aggiungi task"));
    QAction *atd = new QAction(tr("aggiungi todo"));
    menu->addAction(at);
    menu->addAction(atd);
    sel->setMenu(menu);
    layout->addWidget(sel,3,0);

    //layout->addWidget(addT,3,0);
    //layout->addWidget(addTD,3,0);
    connect(at, SIGNAL(triggered()), this, SLOT(addNewTaskSlot()));
    connect(atd,SIGNAL(triggered()), this, SLOT(addNewToDoSlot()));
}

void MainWindow::addNewToDoSlot(){
    QPushButton *saveToDo = new QPushButton("Salva");
    QGridLayout *layNew = new QGridLayout();
    QLabel *nomeE = new QLabel("Nome toDo: ");
    nomeToDo = new QTextEdit();
    nomeToDo->setMaximumHeight(35);


    layout->addLayout(layNew,4,0);
    layNew->addWidget(nomeE);
    layNew->addWidget(nomeToDo);
    layNew->addWidget(saveToDo);

    connect(saveToDo, SIGNAL(clicked()), this, SLOT(addNewToDo()));

}

void MainWindow::addNewToDo(){
    std::cout<<"adding new toDo . . ."<<std::endl;
    api->insertToDo(calendarTmp->getId(), nomeToDo->toPlainText().toStdString());
}


void MainWindow::addNewTaskSlot(){
    QPushButton *saveNew = new QPushButton("Salva");
    QGridLayout *layNew = new QGridLayout();
    layout->addLayout(layNew,4,0);
    QLabel *nomeE = new QLabel("Nome evento: ");
    QLabel *dataI = new QLabel("Ora Inizio: ");
    QLabel *dataF = new QLabel("Ora Fine: ");
    QLabel *data = new QLabel("Data: ");
    QDate dataa = calendar->selectedDate();
    std::string giorno = std::to_string(dataa.day());
    std::string mese = std::to_string(dataa.month());
    std::string anno = std::to_string(dataa.year());
    std::string pippoBaudo = anno+"-"+mese+"-"+giorno;
    editNomeE = new QTextEdit(); editNomeE->setMaximumHeight(35);
    editDataI = new QTextEdit(); editDataI->setMaximumHeight(35);
    editDataF = new QTextEdit(); editDataF->setMaximumHeight(35);
    editData = new QTextEdit(pippoBaudo.c_str()); editData ->setMaximumHeight(35); editData->setReadOnly(true);

    layNew->addWidget(nomeE);
    layNew->addWidget(editNomeE);
    layNew->addWidget(dataI);
    layNew->addWidget(editDataI);
    layNew->addWidget(dataF);
    layNew->addWidget(editDataF);
    layNew->addWidget(data);
    layNew->addWidget(editData);
    layNew->addWidget(saveNew);

    connect(saveNew, SIGNAL(clicked()), this, SLOT(addNewTask()));
}

void MainWindow::addNewTask(){
    std::cout<<"adding new task . . ."<<std::endl;
    //data nel formato YYYY-MM-DDTHH:MM:SS+01:00
    std::string startd = editData->toPlainText().toStdString()+"T"+editDataI->toPlainText().toStdString()+":00+01:00";
    std::string endd = editData->toPlainText().toStdString()+"T"+editDataF->toPlainText().toStdString()+":00+01:00";

    api->insertEvent(calendarTmp->getId(), editNomeE->toPlainText().toStdString(), startd, endd);
}

void MainWindow::selectEventTitle(int index){
    std::cout<<index<<std::endl;
    int c = 0;
    for(auto x : eventi){
        if(c==index){
            eventTmp = x;
            break;
        }
        c++;
    }
    std::cout<<eventTmp->toString()<<std::endl;
    modal();
}

void MainWindow::modal(){
    QPushButton *modifyEv = new QPushButton("modificami");
    QPushButton *hideInfo = new QPushButton("Nascondi info");
    QPushButton *deleteEv = new QPushButton("eliminami");
    if(l2==nullptr){
        l2 = new QGridLayout;
        layout->addLayout(l2,0,2);
        QLabel *starting = new QLabel("Info: ");
        QLabel *nomeE = new QLabel("Nome evento: ");
        titolo = new QLabel();
        titolo->setText(eventTmp->getSummary().c_str());
        QLabel *dataI = new QLabel("Ora Inizio: ");
        QLabel *dataI2 = new QLabel();
        dataI2->setText(eventTmp->getStartDate().substr(11,5).c_str());
        QLabel *dataF = new QLabel("Ora Fine: ");
        QLabel *dataF2 = new QLabel();
        dataF2->setText(eventTmp->getEndDate().substr(11,5).c_str());

        l2->addWidget(starting);        widgetInfo.push_back(starting);
        l2->addWidget(nomeE);           widgetInfo.push_back(nomeE);
        l2->addWidget(titolo);          widgetInfo.push_back(titolo);
        l2->addWidget(dataI);           widgetInfo.push_back(dataI);
        l2->addWidget(dataI2);          widgetInfo.push_back(dataI2);
        l2->addWidget(dataF);           widgetInfo.push_back(dataF);
        l2->addWidget(dataF2);          widgetInfo.push_back(dataF2);
        l2->addWidget(hideInfo);        widgetInfo.push_back(hideInfo);
        l2->addWidget(modifyEv);        widgetInfo.push_back(modifyEv);
        l2->addWidget(deleteEv);        widgetInfo.push_back(deleteEv);
    }
    else{
        /*l2->removeWidget(titolo);
        layout->removeItem(l2);
        l2 = new QGridLayout;
        layout->addLayout(l2,0,2);
        titolo = new QLabel();
        titolo->setText(eventTmp->getSummary().c_str());
        l2->addWidget(titolo);
        l2->addWidget(modifyEv);
        l2->addWidget(deleteEv);*/
    }
    connect(modifyEv,SIGNAL(clicked()), this, SLOT(bau()));
    connect(deleteEv, SIGNAL(clicked()), this, SLOT(deleteEvent()));
    connect(hideInfo, SIGNAL(clicked()), this, SLOT(nascondiInfo()));
    //DANNI
    //connect(this, SIGNAL(makeGetGreatAgain()), this, SLOT(getEventsByDay()));
}

void MainWindow::nascondiInfo(){
    //da implementare
}

void MainWindow::selectCalendarTitle(int index){
    std::cout<<index<<std::endl;
    //QString title= calendarList->itemData(index).toString();
    //std::string tt= title.toString().toStdString();
    //std::cout<<title.toStdString().c_str()<<std::endl;
    int c = 0;
    for(auto x : calendari){
        if(c==index){
            //ho trovato quello giusto e lo metto da parte in una variabile
            calendarTmp=x;
            //std::cout<<"farò una get a "<<calendarTmp->getId()<<std::endl;
            break;
        }
        c++;
    }

    api->getToDos(calendarTmp->getId());
    //una volta selezionato il calendario, posso mostrare il bottone per prendere i todo di quel calendario
    QPushButton *button1 = new QPushButton("get ToDos");
    layout->addWidget(button1, 3,1);
    connect(button1, SIGNAL(clicked()), this, SLOT(getToDos()));

}

void MainWindow::bau(){

    QGridLayout *layEdit = new QGridLayout;
    teEdit = new QTextEdit();
    dEdit= new QTextEdit();
    oraInizioEdit = new QTextEdit();
    oraFineEdit = new QTextEdit();
    QLabel *t = new QLabel();
    t->setText("Titolo evento:");
    QLabel *d = new QLabel();
    d->setText("Data:");
    dEdit->setFixedHeight(35);
    dEdit->setText(eventTmp->getStartDate().substr(0,10).c_str());
    teEdit->setText(eventTmp->getSummary().c_str());
    teEdit->setFixedHeight(35);
    QLabel *oi = new QLabel();
    oi->setText("Ora inizio:");
    QLabel *of = new QLabel();
    of->setText("Ora non inizio:");


    oraInizioEdit->setFixedHeight(35);
    oraFineEdit->setFixedHeight(35);
    oraInizioEdit->setText(eventTmp->getStartDate().substr(11,5).c_str());
    oraFineEdit->setText(eventTmp->getEndDate().substr(11,5).c_str());
    QPushButton *salvaMod = new QPushButton("Salva Modifiche");
    layEdit->addWidget(t);
    layEdit->addWidget(teEdit);
    layEdit->addWidget(d);
    layEdit->addWidget(dEdit);
    layEdit->addWidget(oi);
    layEdit->addWidget(oraInizioEdit);
    layEdit->addWidget(of);
    layEdit->addWidget(oraFineEdit);
    layout->addLayout(layEdit,4,1);
    layout->addWidget(salvaMod,4,2);
    widgetEdit.push_back(t);
    widgetEdit.push_back(teEdit);
    widgetEdit.push_back(d);
    widgetEdit.push_back(dEdit);
    widgetEdit.push_back(oi);
    widgetEdit.push_back(oraInizioEdit);
    widgetEdit.push_back(of);
    widgetEdit.push_back(oraFineEdit);
    widgetEdit.push_back(salvaMod);
    connect(salvaMod, SIGNAL(clicked()), this, SLOT(updateTask()));

}


void MainWindow::updateTask(){
    for(auto x : widgetEdit){ x->hide(); widgetEdit.clear(); }
    std::cout<<"started aggiornamento task"<<std::endl;
    //costruisco startDate e endDate del formato YYYY-MM-DDTHH:MM:SS+01:00
    std::string startd = eventTmp->getStartDate().substr(0,10)+"T"+oraInizioEdit->toPlainText().toStdString()+":00+01:00";
    std::string endd = eventTmp->getStartDate().substr(0,10)+"T"+oraFineEdit->toPlainText().toStdString()+":00+01:00";
    //gestire gui
    api->updateEvent(calendarTmp->getId(), eventTmp->getId(), teEdit->toPlainText().toStdString(), startd, endd);

}

void MainWindow::deleteEvent(){
    std::cout<<"started eliminazione evento"<<std::endl;
    api->deleteEvent(calendarTmp->getId(),eventTmp->getId());
    emit makeGetGreatAgain();
}

void MainWindow::miao(){
    //emit toMyNet();
    std::cout<<"miao miao miao"<<std::endl;
    api->getCalendars();
}


void MainWindow::openNewWindow()
{
    //mMyNewWindow = new NewWindow();
    std::cout<<"fabiòla"<<std::endl;
    //a->getInstance();
    //a->insertCalendar();
    //mMyNewWindow->show();

}
void MainWindow::on_mMyButton_clicked()
{
    openNewWindow();
}
void MainWindow::localeChanged(int index)
{
    const QLocale newLocale(localeCombo->itemData(index).toLocale());
    calendar->setLocale(newLocale);
    int newLocaleFirstDayIndex = firstDayCombo->findData(newLocale.firstDayOfWeek());
    firstDayCombo->setCurrentIndex(newLocaleFirstDayIndex);
}

//! [1]
void MainWindow::firstDayChanged(int index)
{
    calendar->setFirstDayOfWeek(Qt::DayOfWeek(
                                    firstDayCombo->itemData(index).toInt()));
}
//! [1]

void MainWindow::selectionModeChanged(int index)
{
    calendar->setSelectionMode(QCalendarWidget::SelectionMode(
                                   selectionModeCombo->itemData(index).toInt()));
}

void MainWindow::horizontalHeaderChanged(int index)
{
    calendar->setHorizontalHeaderFormat(QCalendarWidget::HorizontalHeaderFormat(
                                            horizontalHeaderCombo->itemData(index).toInt()));
}

void MainWindow::verticalHeaderChanged(int index)
{
    calendar->setVerticalHeaderFormat(QCalendarWidget::VerticalHeaderFormat(
                                          verticalHeaderCombo->itemData(index).toInt()));
}

//! [2]
void MainWindow::selectedDateChanged() {
    currentDateEdit->setDate(calendar->selectedDate());
    std::cout<<currentDateEdit<<std::endl;
}
//! [2]

//! [3]
void MainWindow::minimumDateChanged(QDate date)
{
    calendar->setMinimumDate(date);
    maximumDateEdit->setDate(calendar->maximumDate());
}
//! [3]

//! [4]
void MainWindow::maximumDateChanged(QDate date)
{
    calendar->setMaximumDate(date);
    minimumDateEdit->setDate(calendar->minimumDate());
}
//! [4]

//! [5]
void MainWindow::weekdayFormatChanged()
{
    QTextCharFormat format;

    format.setForeground(qvariant_cast<QColor>(
                             weekdayColorCombo->itemData(weekdayColorCombo->currentIndex())));
    calendar->setWeekdayTextFormat(Qt::Monday, format);
    calendar->setWeekdayTextFormat(Qt::Tuesday, format);
    calendar->setWeekdayTextFormat(Qt::Wednesday, format);
    calendar->setWeekdayTextFormat(Qt::Thursday, format);
    calendar->setWeekdayTextFormat(Qt::Friday, format);
}
//! [5]

//! [6]
void MainWindow::weekendFormatChanged()
{
    QTextCharFormat format;

    format.setForeground(qvariant_cast<QColor>(
                             weekendColorCombo->itemData(weekendColorCombo->currentIndex())));
    calendar->setWeekdayTextFormat(Qt::Saturday, format);
    calendar->setWeekdayTextFormat(Qt::Sunday, format);
}
//! [6]

//! [7]
void MainWindow::reformatHeaders()
{
    QString text = headerTextFormatCombo->currentText();
    QTextCharFormat format;

    if (text == tr("Bold"))
        format.setFontWeight(QFont::Bold);
    else if (text == tr("Italic"))
        format.setFontItalic(true);
    else if (text == tr("Green"))
        format.setForeground(Qt::green);
    calendar->setHeaderTextFormat(format);
}
//! [7]

//! [8]
void MainWindow::reformatCalendarPage()
{
    QTextCharFormat mayFirstFormat;
    const QDate mayFirst(calendar->yearShown(), 5, 1);

    QTextCharFormat firstFridayFormat;
    QDate firstFriday(calendar->yearShown(), calendar->monthShown(), 1);
    while (firstFriday.dayOfWeek() != Qt::Friday)
        firstFriday = firstFriday.addDays(1);

    if (firstFridayCheckBox->isChecked()) {
        firstFridayFormat.setForeground(Qt::blue);
    } else { // Revert to regular colour for this day of the week.
        Qt::DayOfWeek dayOfWeek(static_cast<Qt::DayOfWeek>(firstFriday.dayOfWeek()));
        firstFridayFormat.setForeground(calendar->weekdayTextFormat(dayOfWeek).foreground());
    }

    calendar->setDateTextFormat(firstFriday, firstFridayFormat);

    // When it is checked, "May First in Red" always takes precedence over "First Friday in Blue".
    if (mayFirstCheckBox->isChecked()) {
        mayFirstFormat.setForeground(Qt::red);
    } else if (!firstFridayCheckBox->isChecked() || firstFriday != mayFirst) {
        // We can now be certain we won't be resetting "May First in Red" when we restore
        // may 1st's regular colour for this day of the week.
        Qt::DayOfWeek dayOfWeek(static_cast<Qt::DayOfWeek>(mayFirst.dayOfWeek()));
        calendar->setDateTextFormat(mayFirst, calendar->weekdayTextFormat(dayOfWeek));
    }

    calendar->setDateTextFormat(mayFirst, mayFirstFormat);
}
//! [8]

//! [9]
//! //QUA DENTRO C'È IL CAZZO DI CALENDARIO, MANNAIA ALLA VACCA
void MainWindow::createPreviewGroupBox()
{
    previewGroupBox = new QGroupBox(tr("Calendario Benedetto"));
    calendar = new QCalendarWidget;
    calendar->setMinimumDate(QDate(1900, 1, 1));
    calendar->setMaximumDate(QDate(3000, 1, 1));
    calendar->setGridVisible(true);

    connect(calendar, &QCalendarWidget::currentPageChanged,
            this, &MainWindow::reformatCalendarPage);
    //Questa connect ti permette di prendere l'evento dato il giorno cliccato
    connect(calendar, &QCalendarWidget::clicked, this, &MainWindow::getEventsByDay  );
    previewLayout = new QGridLayout;
    previewLayout->addWidget(calendar, 0, 0, Qt::AlignCenter);
    previewGroupBox->setLayout(previewLayout);
}
//! [9]

// TODO: use loc.name() as label (but has underscore in place of slash)
// TODO: use locale() == loc instead of only comparing language and territory
// Needs someone familiar with this example to work out ramifications
//! [10]
void MainWindow::createGeneralOptionsGroupBox(){

    generalOptionsGroupBox = new QGroupBox(tr("Calendar Preferences"));

    localeCombo = new QComboBox;
    int curLocaleIndex = -1;
    int index = 0;
    for (int _lang = QLocale::C; _lang <= QLocale::LastLanguage; ++_lang) {
        QLocale::Language lang = static_cast<QLocale::Language>(_lang);
        const auto locales =
                QLocale::matchingLocales(lang, QLocale::AnyScript, QLocale::AnyTerritory);
        for (auto loc : locales) {
            QString label = QLocale::languageToString(lang);
            auto territory = loc.territory();
            label += QLatin1Char('/');
            label += QLocale::territoryToString(territory);
            if (locale().language() == lang && locale().territory() == territory)
                curLocaleIndex = index;
            localeCombo->addItem(label, loc);
            ++index;
        }
    }
    if (curLocaleIndex != -1)
        localeCombo->setCurrentIndex(curLocaleIndex);
    localeLabel = new QLabel(tr("&Locale"));
    localeLabel->setBuddy(localeCombo);

    firstDayCombo = new QComboBox;
    firstDayCombo->addItem(tr("Sunday"), Qt::Sunday);
    firstDayCombo->addItem(tr("Monday"), Qt::Monday);
    firstDayCombo->addItem(tr("Tuesday"), Qt::Tuesday);
    firstDayCombo->addItem(tr("Wednesday"), Qt::Wednesday);
    firstDayCombo->addItem(tr("Thursday"), Qt::Thursday);
    firstDayCombo->addItem(tr("Friday"), Qt::Friday);
    firstDayCombo->addItem(tr("Saturday"), Qt::Saturday);

    firstDayLabel = new QLabel(tr("Wee&k starts on:"));
    firstDayLabel->setBuddy(firstDayCombo);
    //! [10]

    selectionModeCombo = new QComboBox;
    selectionModeCombo->addItem(tr("Single selection"),
                                QCalendarWidget::SingleSelection);
    selectionModeCombo->addItem(tr("None"), QCalendarWidget::NoSelection);

    selectionModeLabel = new QLabel(tr("&Selection mode:"));
    selectionModeLabel->setBuddy(selectionModeCombo);

    //CARINO PER LA GRAFICA: NASCONDE LA GRIGLIA (CI PENSIAMO DOPO)
    gridCheckBox = new QCheckBox(tr("&Grid"));
    gridCheckBox->setChecked(calendar->isGridVisible());
    //LO STESSO DI SOPRA
    navigationCheckBox = new QCheckBox(tr("&Navigation bar"));
    navigationCheckBox->setChecked(true);

    horizontalHeaderCombo = new QComboBox;
    horizontalHeaderCombo->addItem(tr("Single letter day names"),
                                   QCalendarWidget::SingleLetterDayNames);
    horizontalHeaderCombo->addItem(tr("Short day names"),
                                   QCalendarWidget::ShortDayNames);
    horizontalHeaderCombo->addItem(tr("None"),
                                   QCalendarWidget::NoHorizontalHeader);
    horizontalHeaderCombo->setCurrentIndex(1);

    horizontalHeaderLabel = new QLabel(tr("&Horizontal header:"));
    horizontalHeaderLabel->setBuddy(horizontalHeaderCombo);

    verticalHeaderCombo = new QComboBox;
    verticalHeaderCombo->addItem(tr("ISO week numbers"),
                                 QCalendarWidget::ISOWeekNumbers);
    verticalHeaderCombo->addItem(tr("None"), QCalendarWidget::NoVerticalHeader);

    verticalHeaderLabel = new QLabel(tr("&Vertical header:"));
    verticalHeaderLabel->setBuddy(verticalHeaderCombo);

    //! [11]
    connect(localeCombo, &QComboBox::currentIndexChanged,
            this, &MainWindow::localeChanged);
    connect(firstDayCombo, &QComboBox::currentIndexChanged,
            this, &MainWindow::firstDayChanged);
    connect(selectionModeCombo, &QComboBox::currentIndexChanged,
            this, &MainWindow::selectionModeChanged);
    connect(gridCheckBox, &QCheckBox::toggled,
            calendar, &QCalendarWidget::setGridVisible);
    connect(navigationCheckBox, &QCheckBox::toggled,
            calendar, &QCalendarWidget::setNavigationBarVisible);
    connect(horizontalHeaderCombo, &QComboBox::currentIndexChanged,
            this, &MainWindow::horizontalHeaderChanged);
    connect(verticalHeaderCombo, &QComboBox::currentIndexChanged,
            this, &MainWindow::verticalHeaderChanged);
    //! [11]

    QHBoxLayout *checkBoxLayout = new QHBoxLayout;
    checkBoxLayout->addWidget(gridCheckBox);
    checkBoxLayout->addStretch();
    checkBoxLayout->addWidget(navigationCheckBox);

    QGridLayout *outerLayout = new QGridLayout;
    outerLayout->addWidget(localeLabel, 0, 0);
    outerLayout->addWidget(localeCombo, 0, 1);
    outerLayout->addWidget(firstDayLabel, 1, 0);
    outerLayout->addWidget(firstDayCombo, 1, 1);
    outerLayout->addWidget(selectionModeLabel, 2, 0);
    outerLayout->addWidget(selectionModeCombo, 2, 1);
    outerLayout->addLayout(checkBoxLayout, 3, 0, 1, 2);
    outerLayout->addWidget(horizontalHeaderLabel, 4, 0);
    outerLayout->addWidget(horizontalHeaderCombo, 4, 1);
    outerLayout->addWidget(verticalHeaderLabel, 5, 0);
    outerLayout->addWidget(verticalHeaderCombo, 5, 1);
    generalOptionsGroupBox->setLayout(outerLayout);

    //! [12]
    firstDayChanged(firstDayCombo->currentIndex());
    selectionModeChanged(selectionModeCombo->currentIndex());
    horizontalHeaderChanged(horizontalHeaderCombo->currentIndex());
    verticalHeaderChanged(verticalHeaderCombo->currentIndex());


}
//! [12]

//! [13]

void MainWindow::createTextFormatsGroupBox()
{
    textFormatsGroupBox = new QGroupBox(tr("Text Formats"));

    weekdayColorCombo = createColorComboBox();
    weekdayColorCombo->setCurrentIndex(
                weekdayColorCombo->findText(tr("Black")));

    weekdayColorLabel = new QLabel(tr("&Weekday color:"));
    weekdayColorLabel->setBuddy(weekdayColorCombo);

    weekendColorCombo = createColorComboBox();
    weekendColorCombo->setCurrentIndex(
                weekendColorCombo->findText(tr("Red")));

    weekendColorLabel = new QLabel(tr("Week&end color:"));
    weekendColorLabel->setBuddy(weekendColorCombo);

    //! [16] //! [17]
    headerTextFormatCombo = new QComboBox;
    headerTextFormatCombo->addItem(tr("Bold"));
    headerTextFormatCombo->addItem(tr("Italic"));
    headerTextFormatCombo->addItem(tr("Plain"));

    headerTextFormatLabel = new QLabel(tr("&Header text:"));
    headerTextFormatLabel->setBuddy(headerTextFormatCombo);

    firstFridayCheckBox = new QCheckBox(tr("&First Friday in blue"));

    mayFirstCheckBox = new QCheckBox(tr("May &1 in red"));

    //! [17] //! [18]
    connect(weekdayColorCombo, &QComboBox::currentIndexChanged,
            this, &MainWindow::weekdayFormatChanged);
    connect(weekdayColorCombo, &QComboBox::currentIndexChanged,
            this, &MainWindow::reformatCalendarPage);
    connect(weekendColorCombo, &QComboBox::currentIndexChanged,
            this, &MainWindow::weekendFormatChanged);
    connect(weekendColorCombo, &QComboBox::currentIndexChanged,
            this, &MainWindow::reformatCalendarPage);
    connect(headerTextFormatCombo, &QComboBox::currentIndexChanged,
            this, &MainWindow::reformatHeaders);
    connect(firstFridayCheckBox, &QCheckBox::toggled,
            this, &MainWindow::reformatCalendarPage);
    connect(mayFirstCheckBox, &QCheckBox::toggled,
            this, &MainWindow::reformatCalendarPage);

    //! [18]
    QHBoxLayout *checkBoxLayout = new QHBoxLayout;
    checkBoxLayout->addWidget(firstFridayCheckBox);
    checkBoxLayout->addStretch();
    checkBoxLayout->addWidget(mayFirstCheckBox);

    QGridLayout *outerLayout = new QGridLayout;
    outerLayout->addWidget(weekdayColorLabel, 0, 0);
    outerLayout->addWidget(weekdayColorCombo, 0, 1);
    outerLayout->addWidget(weekendColorLabel, 1, 0);
    outerLayout->addWidget(weekendColorCombo, 1, 1);
    outerLayout->addWidget(headerTextFormatLabel, 2, 0);
    outerLayout->addWidget(headerTextFormatCombo, 2, 1);
    outerLayout->addLayout(checkBoxLayout, 3, 0, 1, 2);
    textFormatsGroupBox->setLayout(outerLayout);

    weekdayFormatChanged();
    weekendFormatChanged();
    //! [19]
    reformatHeaders();
    reformatCalendarPage();
}
//! [19]

//! [20]
QComboBox *MainWindow::createColorComboBox()
{
    QComboBox *comboBox = new QComboBox;
    comboBox->addItem(tr("Red"), QColor(Qt::red));
    comboBox->addItem(tr("Blue"), QColor(Qt::blue));
    comboBox->addItem(tr("Black"), QColor(Qt::black))
            ;
    comboBox->addItem(tr("Magenta"), QColor(Qt::magenta));
    return comboBox;
}
//! [20]
