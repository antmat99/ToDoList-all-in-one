#include "mainwindow.h"


MainWindow::MainWindow(QWidget *parent)
    : QWidget(parent),
      ui(new Ui::MainWindow)
{



    createPreviewGroupBox();
    createGeneralOptionsGroupBox();
    createTextFormatsGroupBox();

    QTextEdit *textEdit = new QTextEdit();
    layout = new QGridLayout;
    layout->addWidget(previewGroupBox, 0, 0);
    layout->addWidget(textEdit,0,1) ;
    //textEdit->setEnabled(false);
    QPushButton *button1 = new QPushButton("Data");
    QPushButton *button2 = new QPushButton("Preferenze Calendario");
    QPushButton *button3 = new QPushButton("Get Calendari");
    //layout->addWidget(textFormatsGroupBox, 1,2);
    layout->addWidget(button1, 3,1);
    layout->addWidget(button2, 2,1);
    layout->addWidget(button3, 1,1);
    layout->setSizeConstraint(QLayout::SetFixedSize);
    setLayout(layout);

    previewLayout->setRowMinimumHeight(1, calendar->sizeHint().height());
    previewLayout->setColumnMinimumWidth(0, calendar->sizeHint().width());

    setWindowTitle(tr("Calendar Widget"));
    api = API::getInstance("");
    connect(button1, SIGNAL(clicked()), this, SLOT(getEventsByDay()));
    connect(button2, SIGNAL(clicked()), this, SLOT(showPreferences()) );
    connect(button3, SIGNAL(clicked()), this, SLOT(miao()));
    connect(api, SIGNAL(signalCalendarList(std::vector<Calendar*>)), this, SLOT(showCalendars(std::vector<Calendar*>)));
    connect(api, SIGNAL(signalEventList(std::vector<Event*>)),this,SLOT(showEvents(std::vector<Event*>)));
}
//! [0]

void MainWindow::getEventsByDay(){

    QDate data = calendar->selectedDate();
    //costruisco la data che mi serve, con formato YYYY-MM-DDTHH:MM:SSZ
    std::string giorno = std::to_string(data.day());
    std::string mese = std::to_string(data.month());
    std::string anno = std::to_string(data.year());
    std::string timeMin = anno+"-"+mese+"-"+giorno+"T00:00:01Z";
    std::string timeMax = anno+"-"+mese+"-"+giorno+"T23:59:59Z";

    std::cout<<"call getEventsByCalendarDay"<<std::endl;
    //qua deve essere fatta la get agli eventi
    api->getEventsByCalendarDay(calendarTmp->getId(),timeMin,timeMax);
}

void MainWindow::showPreferences(){
    layout->addWidget(generalOptionsGroupBox, 0, 2);
}
void MainWindow::showCalendars(std::vector<Calendar *> ret){
    //salvo l'elenco di calendari in una variabile
    calendari = ret;
    for(int i = 0; i<ret.size(); i++){
        std::cout<<ret.at(i)->toString()<<"\n"<<std::endl;
    }
    //GESTIONE MENU A TENDINA
    calendarList = new QComboBox;
    for(auto el : ret){
        calendarList->addItem(tr(el->getSummary().c_str()));
    }
    layout->addWidget(calendarList,1,0);
    connect(calendarList, &QComboBox::currentIndexChanged, this, &MainWindow::selectCalendarTitle);
}

void MainWindow::showEvents(std::vector<Event *> ret){
    for( int i = 0;i<ret.size();i++){
        std::cout<<ret.at(i)->toString()<<"\n"<<std::endl;
    }
}

void MainWindow::selectCalendarTitle(int index){
    std::cout<<index<<std::endl;
    //QString title= calendarList->itemData(index).toString();
    //std::string tt= title.toString().toStdString();
    //std::cout<<title.toStdString().c_str()<<std::endl;
    int c = 0;
    for(auto x : calendari){
        if(c==index){
            //ho trovato quello giusto e lo metto da parte in una variabile
            calendarTmp=x;
            std::cout<<"farò una get a "<<calendarTmp->getId()<<std::endl;
            break;
        }
        c++;
    }
}

void MainWindow::miao(){
    //emit toMyNet();
    std::cout<<"miao miao miao"<<std::endl;
    api->getCalendars();
}


void MainWindow::openNewWindow()
{
    //mMyNewWindow = new NewWindow();
    std::cout<<"fabiòla"<<std::endl;
    //a->getInstance();
    //a->insertCalendar();
    //mMyNewWindow->show();

}
void MainWindow::on_mMyButton_clicked()
{
    openNewWindow();
}
void MainWindow::localeChanged(int index)
{
    const QLocale newLocale(localeCombo->itemData(index).toLocale());
    calendar->setLocale(newLocale);
    int newLocaleFirstDayIndex = firstDayCombo->findData(newLocale.firstDayOfWeek());
    firstDayCombo->setCurrentIndex(newLocaleFirstDayIndex);
}

//! [1]
void MainWindow::firstDayChanged(int index)
{
    calendar->setFirstDayOfWeek(Qt::DayOfWeek(
                                    firstDayCombo->itemData(index).toInt()));
}
//! [1]

void MainWindow::selectionModeChanged(int index)
{
    calendar->setSelectionMode(QCalendarWidget::SelectionMode(
                                   selectionModeCombo->itemData(index).toInt()));
}

void MainWindow::horizontalHeaderChanged(int index)
{
    calendar->setHorizontalHeaderFormat(QCalendarWidget::HorizontalHeaderFormat(
                                            horizontalHeaderCombo->itemData(index).toInt()));
}

void MainWindow::verticalHeaderChanged(int index)
{
    calendar->setVerticalHeaderFormat(QCalendarWidget::VerticalHeaderFormat(
                                          verticalHeaderCombo->itemData(index).toInt()));
}

//! [2]
void MainWindow::selectedDateChanged() {
        currentDateEdit->setDate(calendar->selectedDate());
        std::cout<<currentDateEdit<<std::endl;
}
//! [2]

//! [3]
void MainWindow::minimumDateChanged(QDate date)
{
    calendar->setMinimumDate(date);
    maximumDateEdit->setDate(calendar->maximumDate());
}
//! [3]

//! [4]
void MainWindow::maximumDateChanged(QDate date)
{
    calendar->setMaximumDate(date);
    minimumDateEdit->setDate(calendar->minimumDate());
}
//! [4]

//! [5]
void MainWindow::weekdayFormatChanged()
{
    QTextCharFormat format;

    format.setForeground(qvariant_cast<QColor>(
                             weekdayColorCombo->itemData(weekdayColorCombo->currentIndex())));
    calendar->setWeekdayTextFormat(Qt::Monday, format);
    calendar->setWeekdayTextFormat(Qt::Tuesday, format);
    calendar->setWeekdayTextFormat(Qt::Wednesday, format);
    calendar->setWeekdayTextFormat(Qt::Thursday, format);
    calendar->setWeekdayTextFormat(Qt::Friday, format);
}
//! [5]

//! [6]
void MainWindow::weekendFormatChanged()
{
    QTextCharFormat format;

    format.setForeground(qvariant_cast<QColor>(
                             weekendColorCombo->itemData(weekendColorCombo->currentIndex())));
    calendar->setWeekdayTextFormat(Qt::Saturday, format);
    calendar->setWeekdayTextFormat(Qt::Sunday, format);
}
//! [6]

//! [7]
void MainWindow::reformatHeaders()
{
    QString text = headerTextFormatCombo->currentText();
    QTextCharFormat format;

    if (text == tr("Bold"))
        format.setFontWeight(QFont::Bold);
    else if (text == tr("Italic"))
        format.setFontItalic(true);
    else if (text == tr("Green"))
        format.setForeground(Qt::green);
    calendar->setHeaderTextFormat(format);
}
//! [7]

//! [8]
void MainWindow::reformatCalendarPage()
{
    QTextCharFormat mayFirstFormat;
    const QDate mayFirst(calendar->yearShown(), 5, 1);

    QTextCharFormat firstFridayFormat;
    QDate firstFriday(calendar->yearShown(), calendar->monthShown(), 1);
    while (firstFriday.dayOfWeek() != Qt::Friday)
        firstFriday = firstFriday.addDays(1);

    if (firstFridayCheckBox->isChecked()) {
        firstFridayFormat.setForeground(Qt::blue);
    } else { // Revert to regular colour for this day of the week.
        Qt::DayOfWeek dayOfWeek(static_cast<Qt::DayOfWeek>(firstFriday.dayOfWeek()));
        firstFridayFormat.setForeground(calendar->weekdayTextFormat(dayOfWeek).foreground());
    }

    calendar->setDateTextFormat(firstFriday, firstFridayFormat);

    // When it is checked, "May First in Red" always takes precedence over "First Friday in Blue".
    if (mayFirstCheckBox->isChecked()) {
        mayFirstFormat.setForeground(Qt::red);
    } else if (!firstFridayCheckBox->isChecked() || firstFriday != mayFirst) {
        // We can now be certain we won't be resetting "May First in Red" when we restore
        // may 1st's regular colour for this day of the week.
        Qt::DayOfWeek dayOfWeek(static_cast<Qt::DayOfWeek>(mayFirst.dayOfWeek()));
        calendar->setDateTextFormat(mayFirst, calendar->weekdayTextFormat(dayOfWeek));
    }

    calendar->setDateTextFormat(mayFirst, mayFirstFormat);
}
//! [8]

//! [9]
//! //QUA DENTRO C'È IL CAZZO DI CALENDARIO, MANNAIA ALLA VACCA
void MainWindow::createPreviewGroupBox()
{
    previewGroupBox = new QGroupBox(tr("Calendario Benedetto"));

    calendar = new QCalendarWidget;
    calendar->setMinimumDate(QDate(1900, 1, 1));
    calendar->setMaximumDate(QDate(3000, 1, 1));
    calendar->setGridVisible(true);

    connect(calendar, &QCalendarWidget::currentPageChanged,
            this, &MainWindow::reformatCalendarPage);
    //Questa connect ti permette di prendere l'evento dato il giorno cliccato
    connect(calendar, &QCalendarWidget::clicked, this, &MainWindow::getEventsByDay  );
    previewLayout = new QGridLayout;
    previewLayout->addWidget(calendar, 0, 0, Qt::AlignCenter);
    previewGroupBox->setLayout(previewLayout);
}
//! [9]

// TODO: use loc.name() as label (but has underscore in place of slash)
// TODO: use locale() == loc instead of only comparing language and territory
// Needs someone familiar with this example to work out ramifications
//! [10]
void MainWindow::createGeneralOptionsGroupBox()
{
    generalOptionsGroupBox = new QGroupBox(tr("Calendar Preferences"));

    localeCombo = new QComboBox;
    int curLocaleIndex = -1;
    int index = 0;
    for (int _lang = QLocale::C; _lang <= QLocale::LastLanguage; ++_lang) {
        QLocale::Language lang = static_cast<QLocale::Language>(_lang);
        const auto locales =
                QLocale::matchingLocales(lang, QLocale::AnyScript, QLocale::AnyTerritory);
        for (auto loc : locales) {
            QString label = QLocale::languageToString(lang);
            auto territory = loc.territory();
            label += QLatin1Char('/');
            label += QLocale::territoryToString(territory);
            if (locale().language() == lang && locale().territory() == territory)
                curLocaleIndex = index;
            localeCombo->addItem(label, loc);
            ++index;
        }
    }
    if (curLocaleIndex != -1)
        localeCombo->setCurrentIndex(curLocaleIndex);
    localeLabel = new QLabel(tr("&Locale"));
    localeLabel->setBuddy(localeCombo);

    firstDayCombo = new QComboBox;
    firstDayCombo->addItem(tr("Sunday"), Qt::Sunday);
    firstDayCombo->addItem(tr("Monday"), Qt::Monday);
    firstDayCombo->addItem(tr("Tuesday"), Qt::Tuesday);
    firstDayCombo->addItem(tr("Wednesday"), Qt::Wednesday);
    firstDayCombo->addItem(tr("Thursday"), Qt::Thursday);
    firstDayCombo->addItem(tr("Friday"), Qt::Friday);
    firstDayCombo->addItem(tr("Saturday"), Qt::Saturday);

    firstDayLabel = new QLabel(tr("Wee&k starts on:"));
    firstDayLabel->setBuddy(firstDayCombo);
    //! [10]

    selectionModeCombo = new QComboBox;
    selectionModeCombo->addItem(tr("Single selection"),
                                QCalendarWidget::SingleSelection);
    selectionModeCombo->addItem(tr("None"), QCalendarWidget::NoSelection);

    selectionModeLabel = new QLabel(tr("&Selection mode:"));
    selectionModeLabel->setBuddy(selectionModeCombo);

    //CARINO PER LA GRAFICA: NASCONDE LA GRIGLIA (CI PENSIAMO DOPO)
    gridCheckBox = new QCheckBox(tr("&Grid"));
    gridCheckBox->setChecked(calendar->isGridVisible());
    //LO STESSO DI SOPRA
    navigationCheckBox = new QCheckBox(tr("&Navigation bar"));
    navigationCheckBox->setChecked(true);

    horizontalHeaderCombo = new QComboBox;
    horizontalHeaderCombo->addItem(tr("Single letter day names"),
                                   QCalendarWidget::SingleLetterDayNames);
    horizontalHeaderCombo->addItem(tr("Short day names"),
                                   QCalendarWidget::ShortDayNames);
    horizontalHeaderCombo->addItem(tr("None"),
                                   QCalendarWidget::NoHorizontalHeader);
    horizontalHeaderCombo->setCurrentIndex(1);

    horizontalHeaderLabel = new QLabel(tr("&Horizontal header:"));
    horizontalHeaderLabel->setBuddy(horizontalHeaderCombo);

    verticalHeaderCombo = new QComboBox;
    verticalHeaderCombo->addItem(tr("ISO week numbers"),
                                 QCalendarWidget::ISOWeekNumbers);
    verticalHeaderCombo->addItem(tr("None"), QCalendarWidget::NoVerticalHeader);

    verticalHeaderLabel = new QLabel(tr("&Vertical header:"));
    verticalHeaderLabel->setBuddy(verticalHeaderCombo);

    //! [11]
    connect(localeCombo, &QComboBox::currentIndexChanged,
            this, &MainWindow::localeChanged);
    connect(firstDayCombo, &QComboBox::currentIndexChanged,
            this, &MainWindow::firstDayChanged);
    connect(selectionModeCombo, &QComboBox::currentIndexChanged,
            this, &MainWindow::selectionModeChanged);
    connect(gridCheckBox, &QCheckBox::toggled,
            calendar, &QCalendarWidget::setGridVisible);
    connect(navigationCheckBox, &QCheckBox::toggled,
            calendar, &QCalendarWidget::setNavigationBarVisible);
    connect(horizontalHeaderCombo, &QComboBox::currentIndexChanged,
            this, &MainWindow::horizontalHeaderChanged);
    connect(verticalHeaderCombo, &QComboBox::currentIndexChanged,
            this, &MainWindow::verticalHeaderChanged);
    //! [11]

    QHBoxLayout *checkBoxLayout = new QHBoxLayout;
    checkBoxLayout->addWidget(gridCheckBox);
    checkBoxLayout->addStretch();
    checkBoxLayout->addWidget(navigationCheckBox);

    QGridLayout *outerLayout = new QGridLayout;
    outerLayout->addWidget(localeLabel, 0, 0);
    outerLayout->addWidget(localeCombo, 0, 1);
    outerLayout->addWidget(firstDayLabel, 1, 0);
    outerLayout->addWidget(firstDayCombo, 1, 1);
    outerLayout->addWidget(selectionModeLabel, 2, 0);
    outerLayout->addWidget(selectionModeCombo, 2, 1);
    outerLayout->addLayout(checkBoxLayout, 3, 0, 1, 2);
    outerLayout->addWidget(horizontalHeaderLabel, 4, 0);
    outerLayout->addWidget(horizontalHeaderCombo, 4, 1);
    outerLayout->addWidget(verticalHeaderLabel, 5, 0);
    outerLayout->addWidget(verticalHeaderCombo, 5, 1);
    generalOptionsGroupBox->setLayout(outerLayout);

    //! [12]
    firstDayChanged(firstDayCombo->currentIndex());
    selectionModeChanged(selectionModeCombo->currentIndex());
    horizontalHeaderChanged(horizontalHeaderCombo->currentIndex());
    verticalHeaderChanged(verticalHeaderCombo->currentIndex());
}
//! [12]

//! [13]

void MainWindow::createTextFormatsGroupBox()
{
    textFormatsGroupBox = new QGroupBox(tr("Text Formats"));

    weekdayColorCombo = createColorComboBox();
    weekdayColorCombo->setCurrentIndex(
                weekdayColorCombo->findText(tr("Black")));

    weekdayColorLabel = new QLabel(tr("&Weekday color:"));
    weekdayColorLabel->setBuddy(weekdayColorCombo);

    weekendColorCombo = createColorComboBox();
    weekendColorCombo->setCurrentIndex(
                weekendColorCombo->findText(tr("Red")));

    weekendColorLabel = new QLabel(tr("Week&end color:"));
    weekendColorLabel->setBuddy(weekendColorCombo);

    //! [16] //! [17]
    headerTextFormatCombo = new QComboBox;
    headerTextFormatCombo->addItem(tr("Bold"));
    headerTextFormatCombo->addItem(tr("Italic"));
    headerTextFormatCombo->addItem(tr("Plain"));

    headerTextFormatLabel = new QLabel(tr("&Header text:"));
    headerTextFormatLabel->setBuddy(headerTextFormatCombo);

    firstFridayCheckBox = new QCheckBox(tr("&First Friday in blue"));

    mayFirstCheckBox = new QCheckBox(tr("May &1 in red"));

    //! [17] //! [18]
    connect(weekdayColorCombo, &QComboBox::currentIndexChanged,
            this, &MainWindow::weekdayFormatChanged);
    connect(weekdayColorCombo, &QComboBox::currentIndexChanged,
            this, &MainWindow::reformatCalendarPage);
    connect(weekendColorCombo, &QComboBox::currentIndexChanged,
            this, &MainWindow::weekendFormatChanged);
    connect(weekendColorCombo, &QComboBox::currentIndexChanged,
            this, &MainWindow::reformatCalendarPage);
    connect(headerTextFormatCombo, &QComboBox::currentIndexChanged,
            this, &MainWindow::reformatHeaders);
    connect(firstFridayCheckBox, &QCheckBox::toggled,
            this, &MainWindow::reformatCalendarPage);
    connect(mayFirstCheckBox, &QCheckBox::toggled,
            this, &MainWindow::reformatCalendarPage);

    //! [18]
    QHBoxLayout *checkBoxLayout = new QHBoxLayout;
    checkBoxLayout->addWidget(firstFridayCheckBox);
    checkBoxLayout->addStretch();
    checkBoxLayout->addWidget(mayFirstCheckBox);

    QGridLayout *outerLayout = new QGridLayout;
    outerLayout->addWidget(weekdayColorLabel, 0, 0);
    outerLayout->addWidget(weekdayColorCombo, 0, 1);
    outerLayout->addWidget(weekendColorLabel, 1, 0);
    outerLayout->addWidget(weekendColorCombo, 1, 1);
    outerLayout->addWidget(headerTextFormatLabel, 2, 0);
    outerLayout->addWidget(headerTextFormatCombo, 2, 1);
    outerLayout->addLayout(checkBoxLayout, 3, 0, 1, 2);
    textFormatsGroupBox->setLayout(outerLayout);

    weekdayFormatChanged();
    weekendFormatChanged();
    //! [19]
    reformatHeaders();
    reformatCalendarPage();
}
//! [19]

//! [20]
QComboBox *MainWindow::createColorComboBox()
{
    QComboBox *comboBox = new QComboBox;
    comboBox->addItem(tr("Red"), QColor(Qt::red));
    comboBox->addItem(tr("Blue"), QColor(Qt::blue));
    comboBox->addItem(tr("Black"), QColor(Qt::black))
            ;
    comboBox->addItem(tr("Magenta"), QColor(Qt::magenta));
    return comboBox;
}
//! [20]
