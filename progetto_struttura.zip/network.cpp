#include "network.h"

Network::Network(QObject *parent) : QObject(parent)
{
    connect(manager,SIGNAL(finished(QNetworkReply*)),this,SLOT(manageReply(QNetworkReply*)));
}//costruttore

void Network::makeGetRequest(QString endpoint){
    std::cout<<"Network: making GET request to "+endpoint.toStdString()<<std::endl;
    QNetworkRequest request;
    request.setUrl(endpoint);
    manager->get(request);
}//makeGetRequest

void Network::makePostRequest(QString endpoint, QByteArray postData){
    std::cout<<"Network: making POST request to "+endpoint.toStdString()<<std::endl;
    QNetworkRequest request;
    request.setUrl(endpoint);
    request.setHeader(QNetworkRequest::ContentTypeHeader,"text/plain");
    manager->post(QNetworkRequest(QUrl(endpoint)),postData);
}//makePostRequest

void Network::makeUpdateRequest(QString endpoint, QByteArray putData){
    //TODO
}//makeUpdateRequest

void Network::makeDeleteRequest(QString endpoint){
    //TODO
}//makeDeleteRequest

/* Slot */

void Network::manageReply(QNetworkReply *reply){
    QByteArray myData=reply->readAll();
    std::string result=myData.toStdString();
    reply->close();
    reply->deleteLater();
    emit networkResponse(result); //verrà preso da API
}//slot manageReply


