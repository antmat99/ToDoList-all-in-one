#include "api.h"

API API::getInstance(){
    //TODO lock e controlli in caso di multithread
    if(instance==nullptr)
        instance=new API();
    return instance;
}//getInstance

API::API(QObject *parent) : QObject(parent){
    //inizializzo i campi
    network=new Network();
    parser=new Parser();

    //connect per ottenere le risposte da network
    connect(network,SIGNAL(networkResponse()),this,SLOT(responseSlot()));

    //POST per ottenere a_code, exp_in e r_token
    try {
        curlpp::Cleanup cleaner;
        curlpp::Easy request;

        //imposto i parametri
        request.setOpt(new curlpp::options::Url(std::string("https://oauth2.googleapis.com/token?code="+t_code+"&client_id=1034786735866-o2d6ot6i3mvvrvt2rck9qent1a32odnb.apps.googleusercontent.com&client_secret=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&grant_type=authorization_code&redirect_uri=http://localhost:8080&code_verifier=1111111111111111111111111111111111111111111").c_str()));
        request.setOpt(new curlpp::options::Verbose(true));

        //TODO: dubbio sul content-type: text plain o application json?
        std::list<std::string> header;
        header.push_back("Content-Type: text/plain");
        //imposto header
        request.setOpt(new curlpp::options::HttpHeader(header));
        //specifico che il body è vuoto
        request.setOpt(new curlpp::options::PostFields("\r"));
        request.setOpt(new curlpp::options::PostFieldSize(0));

        //metto da parte la risposta che otterrò
        std::ostringstream body;
        //il body della risposta alla post viene salvato in response
        request.setOpt(new curlpp::options::WriteStream(&body));

        //eseguo post
        request.perform();
        std::cout<<"-----------"<<std::endl;
        //stampa del body
        std::cout<<body.str()<<std::endl;

        //splitto per prendere i parametri che mi servono
        std::vector<std::string> v = split(body.str(), " ");

        //salvo le var che userò per inserirle nelle varie richieste
        a_code = v[3];      //access_token
        exp_in = v[6];      //expires_in
        r_token = v[9];     //refresh_token

        //elimino "" e , siccome ho splittato il testo da json
        a_code.erase(std::remove(a_code.begin(), a_code.end(), '\"'), a_code.end());
        a_code.erase(std::remove(a_code.begin(), a_code.end(), ','), a_code.end());
        exp_in.erase(std::remove(exp_in.begin(), exp_in.end(), ','), exp_in.end());
        r_token.erase(std::remove(r_token.begin(), r_token.end(), '\"'), r_token.end());
        r_token.erase(std::remove(r_token.begin(), r_token.end(), ','), r_token.end());
    }
    catch ( curlpp::LogicError & e ) {
        std::cout << e.what() << std::endl;
    }
    catch ( curlpp::RuntimeError & e ) {
        std::cout << e.what() << std::endl;
    }
}//costruttore

std::vector<std::string> API::split (std::string s, std::string delimiter) {
    size_t pos_start = 0, pos_end, delim_len = delimiter.length();
    std::string token;
    std::vector<std::string> res;

    while ((pos_end = s.find (delimiter, pos_start)) != std::string::npos) {
        token = s.substr (pos_start, pos_end - pos_start);
        pos_start = pos_end + delim_len;
        res.push_back (token);
    }

    res.push_back (s.substr (pos_start));
    return res;
}//split

std::string API::getCalendars(){
    //fa solo la richiesta: la risposta va presa tramite una connect al signal di network
    std::string url = std::string("https://www.googleapis.com/calendar/v3/users/me/calendarList?access_token="+a_code);
    network->makeGetRequest(url.c_str());
}//getCalendars

void API::insertCalendar(){

}//insertCalendar

void API::deleteCalendar(std::string calendar_id){

}//deleteCalendar

void API::shareCalendar(std::string calendar_id){

}//shareCalendar

std::string API::getEventsByCalendarDay(std::string calendar_id, std::string date){

}//getEventsByCalendarDay

void API::insertEvent(std::string calendar_id, std::string description, std::string begin_date, std::string endDate){

}//insertEvent

void API::deleteEvent(std::string calendar_id, std::string event_id){

}//deleteEvent

void API::updateEventDescription(std::string calendar_id, std::string event_id, std::string new_description){

}//updateEventDescription

void API::updateEventStartDate(std::string calendar_id, std::string event_id, std::string start_date){

}//updateEventStartDate

/* Slot */

void API::responseSlot(std::string response){
    //TODO capire se fare il parsing ed eventualmente farlo
    //emit apiResult(stringa parsata) //verrà preso dalla gui
}//responseSlot
