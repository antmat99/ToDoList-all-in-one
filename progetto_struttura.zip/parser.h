#ifndef PARSER_H
#define PARSER_H


class Parser
{
public:
    Parser();
};

#endif // PARSER_H
