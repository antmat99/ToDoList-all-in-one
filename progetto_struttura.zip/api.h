#ifndef API_H
#define API_H

#define CPPHTTPLIB_OPENSSL_SUPPORT

#include <curl/curl.h>
#include <curlpp/cURLpp.hpp>
#include <curlpp/Easy.hpp>
#include <curlpp/Options.hpp>
#include <sstream> //per ostringstream
#include <vector>
#include "network.h"
#include "parser.h"
#include <QObject>

using namespace curlpp::options;

/*
Basata su singleton. Alla prima costruzione si fa la post per ottenere i valori (auth code, ecc)

TODO:   - prima di ogni chiamata bisognerebbe chiamare una funzione che eventualmente si occupi
        del refresh del token

        - vedere se il tipo di ritorno delle funzioni dev'essere std::string
*/


class API : public QObject {
    Q_OBJECT
public:
    API getInstance();
    /* Funzioni sui calendari */
    std::string getCalendars(); //senza parametri perché l'utente si capisce con l'auth code nella richiesta
    void insertCalendar(); //senza parametri perché l'utente si capisce con l'auth code nella richiesta
    void deleteCalendar(std::string calendar_id);
    void shareCalendar(std::string calendar_id);
    /* Funzioni sugli eventi */
    std::string getEventsByCalendarDay(std::string calendar_id, std::string date);
    void insertEvent(std::string calendar_id, std::string description, std::string begin_date, std::string endDate); //TODO ritorna l'id dell'evento?
    void deleteEvent(std::string calendar_id, std::string event_id);
    void updateEventDescription(std::string calendar_id, std::string event_id, std::string new_description);
    void updateEventStartDate(std::string calendar_id, std::string event_id, std::string start_date);

/*
Gli slot catturano i signal emessi da network e a loro volta emettono signal che verranno
presi dai componenti della gui
*/
public slots:
    void responseSlot(std::string response);

/*
I signal emessi da API verranno presi dalla gui per mostrare a schermo i risultati
*/
signals:
    void apiResult(std::string);

private:
    API instance;

    std::string a_code;
    std::string r_token;
    std::string exp_in;
    Network *network; //TODO da inizializzare alla costruzione
    Parser *parser; //TODO da inizializzare alla costruzione

    API(QObject *parent = 0); //costruttore privato
    std::vector<std::string> split(std::string s, std::string delimiter);

};

#endif // API_H
