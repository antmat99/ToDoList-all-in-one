#ifndef WINDOW_H
#define WINDOW_H

#include <QWidget>
#include <QDateTime>
#include "ui_mainwindow.h"
#include "api.h"
#include "calendar.h"
#include "event.h"
#include <QCalendarWidget>
#include <QCheckBox>
#include <QComboBox>
#include <QDateEdit>
#include <QGridLayout>
#include <QGroupBox>
#include <QLabel>
#include <QLocale>
#include <QTextCharFormat>
#include <QTextEdit>
#include <QPushButton>
#include <iostream>
#include <QButtonGroup>

QT_BEGIN_NAMESPACE
class QCalendarWidget;
class QCheckBox;
class QComboBox;
class QDate;
class QDateEdit;
class QGridLayout;
class QGroupBox;
class QLabel;
QT_END_NAMESPACE

//! [0]
class MainWindow : public QWidget
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    API *api;
    QGridLayout *layout;
    QGridLayout *l2;
    std::vector<Calendar*> calendari;
    std::vector<Event*> eventi;
    Calendar *calendarTmp;
    Event *eventTmp;
    QCalendarWidget *calendar;
    QTextEdit *textEdit;
    QLabel *titolo;

private:
    Ui::MainWindow *ui;

public slots:
    void deleteEvent();
    void openNewWindow();
    void showPreferences();
    void miao();
    void getEventsByDay();
    void showCalendars(std::vector<Calendar *> ret);
    void showEvents(std::vector<Event *> ret);
private slots:
    void selectEventTitle(int index);
    void selectCalendarTitle(int index);
    void localeChanged(int index);
    void firstDayChanged(int index);
    void selectionModeChanged(int index);
    void horizontalHeaderChanged(int index);
    void verticalHeaderChanged(int index);
    void selectedDateChanged();
    void minimumDateChanged(QDate date);
    void maximumDateChanged(QDate date);
    void weekdayFormatChanged();
    void weekendFormatChanged();
    void reformatHeaders();
    void reformatCalendarPage();
    void on_mMyButton_clicked();

signals:
    void toMyNet();
    void makeGetGreatAgain();
private:
    void modal();
    //NewWindow *mMyNewWindow;
    void createPreviewGroupBox();
    void createTextFormatsGroupBox();
    void createGeneralOptionsGroupBox();
    QComboBox *createColorComboBox();
    QGroupBox *previewGroupBox;
    QGridLayout *previewLayout;
    QDateEdit *currentDateEdit;
    QLabel *localeLabel;
    QLabel *firstDayLabel;
    //! [0]
    QLabel *selectionModeLabel;
    QLabel *horizontalHeaderLabel;
    QLabel *verticalHeaderLabel;
    QComboBox *localeCombo;
    QComboBox *firstDayCombo;
    QComboBox *calendarList;
    QComboBox *eventList;
    QComboBox *selectionModeCombo;
    QCheckBox *gridCheckBox;
    QCheckBox *navigationCheckBox;
    QComboBox *horizontalHeaderCombo;
    QComboBox *verticalHeaderCombo;
    QGroupBox *generalOptionsGroupBox;
    QGroupBox *datesGroupBox;
    QLabel *currentDateLabel;
    QLabel *minimumDateLabel;
    QLabel *maximumDateLabel;
    QDateEdit *minimumDateEdit;
    QDateEdit *maximumDateEdit;

    QGroupBox *textFormatsGroupBox;
    QLabel *weekdayColorLabel;
    QLabel *weekendColorLabel;
    QLabel *headerTextFormatLabel;
    QComboBox *weekdayColorCombo;
    QComboBox *weekendColorCombo;
    QComboBox *headerTextFormatCombo;

    QCheckBox *firstFridayCheckBox;
    //! [1]
    QCheckBox *mayFirstCheckBox;
};
//! [1]

#endif
