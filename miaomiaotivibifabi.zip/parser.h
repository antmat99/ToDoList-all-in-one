#ifndef PARSER_H
#define PARSER_H

#include "calendar.h"
#include "event.h"
#include <vector>
#include <iostream>
#include <QJsonObject>
#include <QString>
#include <QJsonDocument>
#include <QJsonArray>

class Parser {
public:
    Parser();
    std::vector<Calendar*> toCalendarList(std::string json);
    Calendar* toCalendar(std::string json);
    std::vector<Event*> toEventList(std::string json);
    Event* toEvent(std::string json);
};

#endif // PARSER_H
