#ifndef MYNETWORK_H
#define MYNETWORK_H

#include <QObject>
#include <iostream>
#include <QNetworkAccessManager>
#include <QNetworkReply>

class MyNetwork : public QObject
{
    Q_OBJECT
public:
    explicit MyNetwork(QObject *parent = 0);
    void makeGetRequest(QString endpoint);
    void makePostRequest(QString endpoint, QByteArray postData);
    std::string readResponse(QNetworkReply *reply);

signals:
    void dataReadyRead(QByteArray);

public slots:
    void readRead(QNetworkReply *reply);


private:
    QNetworkAccessManager *manager=new QNetworkAccessManager(this);

};

#endif // MYNETWORK_H
