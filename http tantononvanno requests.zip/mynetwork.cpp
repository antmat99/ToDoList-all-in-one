#include "mynetwork.h"

MyNetwork::MyNetwork(QObject *parent) : QObject(parent)
{
    connect(manager,SIGNAL(finished(QNetworkReply*)),this,SLOT(readRead(QNetworkReply*)));
    //connect(reply,SIGNAL(readyRead()),this,SLOT(readRead(QNetworkReply*)));
}

void MyNetwork::makeGetRequest(QString endpoint){
    std::cout<<"MyNetwork: making GET request to "+endpoint.toStdString()<<std::endl;
    QNetworkRequest request;
    request.setUrl(endpoint);
    manager->get(request);
}

void MyNetwork::makePostRequest(QString endpoint, QByteArray postData){
    //std::cout<<"MyNetwork: making POST request to "+endpoint.toStdString()<<std::endl;
    QNetworkRequest request;
    request.setUrl(endpoint);
    request.setHeader(QNetworkRequest::ContentTypeHeader,"application-json");
    manager->post(QNetworkRequest(QUrl(endpoint)),postData);
}

void MyNetwork::readRead(QNetworkReply *reply){
    std::cout<<"MyNetwork: entering readRead"<<std::endl;
    QByteArray myData=reply->readAll();
    std::cout<<"Got response: "+myData.toStdString()<<std::endl;
    reply->close();
    reply->deleteLater();
}


