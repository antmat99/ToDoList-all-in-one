#define CPPHTTPLIB_OPENSSL_SUPPORT

#include "mainwindow.h"
#include "mynetwork.h"

#include <QApplication>
#include <QtNetwork/QNetworkAccessManager>
#include <QtNetwork/QNetworkReply>
#include <stdio.h>
#include <stdlib.h>
#include <cpp-httplib-master/httplib.h>
#include <QDesktopServices>
#include <QUrl>
#include <QUrlQuery>
#include <thread>
#include <vector>
#include <QObject>

std::mutex m;
std::condition_variable cv;

std::string t_code = "";
std::string a_code = "";
std::string r_token ="";
std::string exp_in = "";

// for string delimiter
std::vector<std::string> split (std::string s, std::string delimiter) {
    size_t pos_start = 0, pos_end, delim_len = delimiter.length();
    std::string token;
    std::vector<std::string> res;

    while ((pos_end = s.find (delimiter, pos_start)) != std::string::npos) {
        token = s.substr (pos_start, pos_end - pos_start);
        pos_start = pos_end + delim_len;
        res.push_back (token);
    }

    res.push_back (s.substr (pos_start));
    return res;
}

//funzione che viene passata al thread per ottenere il token code da inserire poi nella post
void listener(){
    std::cout<<"server on"<<std::endl;
    httplib::Server svr;
    svr.Get("/", [](const httplib::Request & req, httplib::Response &res) {
        std::unique_lock<std::mutex> ul(m);
        res.set_content("Puoi chiudere questa pagina !", "text/plain");
        t_code = req.get_param_value("code");
        //std::cout<<t_code<<std::endl;
        cv.notify_all();
    });
    std::cout<<"server listening.."<<std::endl;
    svr.listen("127.0.0.1", 8080);
}

int main(int argc, char *argv[]){
std::unique_lock<std::mutex> ul(m);
    QApplication a(argc, argv);
    MainWindow w;
    //w.show();
    //return a.exec();

    //apre il browser con il link passato
    //QDesktopServices::openUrl(QUrl("https://accounts.google.com/o/oauth2/v2/auth?client_id=1034786735866-o2d6ot6i3mvvrvt2rck9qent1a32odnb.apps.googleusercontent.com&response_type=code&scope=https://www.googleapis.com/auth/calendar&redirect_uri=http://localhost:8080&code_challenge=1111111111111111111111111111111111111111111&challenge_method=plain"));

    //creo un thread per stare in ascolto su localhost:8080
    //std::thread t1{listener};

    //cv.wait(ul);

    //inizializzo il gestore delle richieste http
    MyNetwork network;
    /*
    //POST request per ottenere a_code, exp_in e r_token
    std::string s = std::string("https://oauth2.googleapis.com/token?code="+t_code+"&client_id=1034786735866-o2d6ot6i3mvvrvt2rck9qent1a32odnb.apps.googleusercontent.com&client_secret=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&grant_type=authorization_code&redirect_uri=http://localhost:8080&code_verifier=1111111111111111111111111111111111111111111");
    std::cout<<"Making POST request to obtain a_code, exp_in e r_token..."<<std::endl;
    QUrlQuery postData;
    postData.addQueryItem("prova","prova");
    network.makePostRequest(s.c_str(),postData.toString(QUrl::FullyEncoded).toUtf8());
    std::cout<<"POST request done. Result is: \n"<<std::endl;
    std::string response = "prova";
    std::cout<<response+'\n'<<std::endl;
    //parso il risultato per prendere a_code, exp_in e r_token
    std::cout<<"Result parsed is: \n"<<std::endl;
    std::vector<std::string> v = split(response, " ");
    a_code = v[3];      //access_token
    exp_in = v[6];      //expires_in
    r_token = v[9];     //refresh_token
    a_code.erase(std::remove(a_code.begin(), a_code.end(), '\"'), a_code.end());
    a_code.erase(std::remove(a_code.begin(), a_code.end(), ','), a_code.end());
    exp_in.erase(std::remove(exp_in.begin(), exp_in.end(), ','), exp_in.end());
    r_token.erase(std::remove(r_token.begin(), r_token.end(), '\"'), r_token.end());
    r_token.erase(std::remove(r_token.begin(), r_token.end(), ','), r_token.end());
    std::cout<<a_code<<std::endl;
    std::cout<<exp_in<<std::endl;
    std::cout<<r_token<<std::endl;
*/
    //GET request per ottenere i calendari
    std::cout<<"Making GET request to obtain calendars..."<<std::endl;
    //std::string s2 = std::string("https://www.googleapis.com/calendar/v3/users/me/calendarList?access_token="+a_code);
    network.makeGetRequest("http://www.google.com");
    std::cout<<"GET request done. Result is: \n"<<std::endl;

    //t1.join();

}





//COSE VECCHIE

/*

//questa funzione viene svegliata quando c'è risposta nella get fatta sopra
//e cambia il valore di t_code
//cosicchè posso fare una post con tutti i parametri che mi servono
void change(QApplication a){

    //se mi trovo qui, mi sono svegliato
    //std::cout<<t_code<<std::endl;
    std::cout<<"-----"<<std::endl;
    //qui devo fare la post, uso libreria curlpp

    try {
        std::unique_lock<std::mutex> ul(m);
        cv.wait(ul);
        curlpp::Cleanup cleaner;
        //cURLpp::initialize();
        curlpp::Easy request;

        //imposto i parametri
        std::string s = std::string("https://oauth2.googleapis.com/token?code="+t_code+"&client_id=1034786735866-o2d6ot6i3mvvrvt2rck9qent1a32odnb.apps.googleusercontent.com&client_secret=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&grant_type=authorization_code&redirect_uri=http://localhost:8080&code_verifier=1111111111111111111111111111111111111111111");
        curlpp::options::Url * url1=new curlpp::options::Url(s);
        request.setOpt(url1);
        request.setOpt(new curlpp::options::Verbose(true));

        //TODO: dubbio sul content-type: text plain o application json?
        std::list<std::string> header;
        header.push_back("Content-Type: text/plain");
        header.push_back("Connection: close");
        //imposto header
        request.setOpt(new curlpp::options::HttpHeader(header));
        //specifico che il body è vuoto
        request.setOpt(new curlpp::options::PostFields("\r"));
        request.setOpt(new curlpp::options::PostFieldSize(0));
        //request.setOpt(CURLOPT_FORBID_REUSE);

        //metto da parte la risposta che otterrò
        std::ostringstream response;
        //il body della risposta alla post viene salvato in response
        request.setOpt(new curlpp::options::WriteStream(&body));
        request.setOpt(new curlpp::options::ForbidReuse(1));
        //eseguo post
        request.perform();
        std::cout<<"-----------"<<std::endl;
        //stampa del body
        std::cout<<body.str()<<std::endl;

        std::cout<<"-----------"<<std::endl;

        //splitto per prendere i parametri che mi servono
        std::vector<std::string> v = split(body.str(), " ");

        a_code = v[3];      //access_token
        exp_in = v[6];      //expires_in
        r_token = v[9];     //refresh_token

        a_code.erase(std::remove(a_code.begin(), a_code.end(), '\"'), a_code.end());
        a_code.erase(std::remove(a_code.begin(), a_code.end(), ','), a_code.end());
        exp_in.erase(std::remove(exp_in.begin(), exp_in.end(), ','), exp_in.end());
        r_token.erase(std::remove(r_token.begin(), r_token.end(), '\"'), r_token.end());
        r_token.erase(std::remove(r_token.begin(), r_token.end(), ','), r_token.end());

        std::cout<<a_code<<std::endl;
        std::cout<<exp_in<<std::endl;
        std::cout<<r_token<<std::endl;

        delete url1;
        //cURLpp::terminate();

        QNetworkAccessManager man;
        //si crea l'oggetto richiesta specificando l'url
        std::string s2 = std::string("https://www.googleapis.com/calendar/v3/users/me/calendarList?access_token="+a_code);
        QNetworkRequest req(QUrl(s2.c_str()));
        QNetworkReply* reply =man.get(req);
        QObject::connect(reply,&QNetworkReply::finished,[&](){
            QByteArray read = reply->readAll(); //read contiene il contenuto della risposta
            //si usa il metodo toStdString() per convertire read a stringa
            std::cout << "Got response:\n" << read.toStdString() << std::endl;
            reply->close();
            reply->deleteLater();
            a.quit();
        });


            std::cout<<"Ciao 1"<<std::endl;
            //provo una get di un calendario passando l'access token nell'header Authorization

            cURLpp::initialize();

            std::cout<<"Ciao 2"<<std::endl;
            curlpp::Easy req2;
            std::ostringstream body2;
            std::list<std::string> headers2;
            headers2.push_back("Connection: close");
            req2.setOpt(new curlpp::options::HttpHeader(headers2));
            std::string s2 = std::string("https://www.googleapis.com/calendar/v3/users/me/calendarList?access_token="+a_code);
            curlpp::options::Url * url2=new curlpp::options::Url(s2);
            req2.setOpt(url2);
            req2.setOpt(new curlpp::options::ForbidReuse(1));
            req2.setOpt(new curlpp::options::FreshConnect(1));
            //req2.setOpt( new curlpp::options::WriteStream( &body2) );


            //setting headers
            //std::cout<<"Setting headers"<<std::endl;
            //std::list<std::string> headers;
            //headers.push_back("Authorization: "+a_code);
            //req2.setOpt(new HttpHeader(headers));

            // send our request to the web server
            std::cout<<"Making GET request"<<std::endl;
            req2.perform();
            std::cout<<"Request done. Response is: "<<std::endl;
            std::cout<<body.str()<<std::endl;

            delete url2;
            //cURLpp::terminate();




    }
    catch ( curlpp::LogicError & e ) {
        std::cout << e.what() << std::endl;
    }
    catch ( curlpp::RuntimeError & e ) {
        std::cout << e.what() << std::endl;
    }



}

void nextRequest(){
    std::unique_lock<std::mutex> ul(m);
    cv2.wait(ul);
    std::cout<<"THREAD 2"<<std::endl;




    try {

        curlpp::Cleanup cleaner;
        //cURLpp::initialize();

        curlpp::Easy req2;
        std::ostringstream body2;
        std::list<std::string> headers2;
        headers2.push_back("Connection: close");
        req2.setOpt(new curlpp::options::HttpHeader(headers2));
        std::string s2 = std::string("https://www.googleapis.com/calendar/v3/users/me/calendarList?access_token="+a_code);
        curlpp::options::Url * url2=new curlpp::options::Url(s2);
        req2.setOpt(url2);
        req2.setOpt(new curlpp::options::ForbidReuse(1));
        req2.setOpt(new curlpp::options::FreshConnect(1));
        //req2.setOpt( new curlpp::options::WriteStream( &body2) );


        //setting headers
        //std::cout<<"Setting headers"<<std::endl;
        //std::list<std::string> headers;
        //headers.push_back("Authorization: "+a_code);
        //req2.setOpt(new HttpHeader(headers));

        // send our request to the web server
        std::cout<<"Making GET request"<<std::endl;
        req2.perform();
        std::cout<<"Request done. Response is: "<<std::endl;
        std::cout<<body.str()<<std::endl;

        delete url2;
        //cURLpp::terminate();




    }
    catch ( curlpp::LogicError & e ) {
        std::cout << e.what() << std::endl;
    }
    catch ( curlpp::RuntimeError & e ) {
        std::cout << e.what() << std::endl;
    }


}

class Prova extends {

    void metodo(){
        QNetworkAccessManager *manager = new QNetworkAccessManager(this);
    }

};

*/
