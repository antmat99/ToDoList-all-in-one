#ifndef WINDOW_H
#define WINDOW_H

#include <QWidget>
#include <QDateTime>
#include "ui_mainwindow.h"
#include "api.h"
#include "calendar.h"
#include "event.h"
#include <QCalendarWidget>
#include <QCheckBox>
#include <QComboBox>
#include <QDateEdit>
#include <QGridLayout>
#include <QGroupBox>
#include <QLabel>
#include <QLocale>
#include <QTextCharFormat>
#include <QTextEdit>
#include <QPushButton>
#include <iostream>
#include <QButtonGroup>
#include <QMessageBox>

QT_BEGIN_NAMESPACE
class QCalendarWidget;
class QCheckBox;
class QComboBox;
class QDate;
class QDateEdit;
class QGridLayout;
class QGroupBox;
class QLabel;
QT_END_NAMESPACE

class MainWindow : public QWidget {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    API *api;                           //istanza singleton che fa richieste
    QGridLayout *layout;                //layout principale
    QGridLayout *l2=nullptr;            //layout per show del task selezionato
    QGridLayout *layButtons;
    QGridLayout *layTE;
    std::vector<Calendar*> calendari;   //elenco prelevato da Google
    std::vector<Event*> eventi;
    std::vector<Event*> toDos;
    Calendar *calendarTmp;              //calendario temporaneo sul quale eseguire ops
    Event *eventTmp;                    //evento temporaneamente selezionato
    Event *toDoTmp;                     //toDo temporaneamente selezionato
    QCalendarWidget *calendar;
    QTextEdit *textEdit;                //area di testo per visione eventi
    QLabel *titolo;                     //contiene il nome dell'evento da modificare
    QPushButton *button22;              //bottone che permette di nascondere le preferenze del calendario
    std::string timeMin;                //data usata per fare getCalendarsByDay
    std::string timeMax;                //variabile = a timeMin per fare getCalendarsByDay

    //blocchi usati per gestire hiding e layout
    QGroupBox *spaceToDoInfo=NULL;          //racchiude le info del toDo
    QGroupBox *spaceToDoModal=NULL;          //racchiude il modal del toDo
    QGroupBox *spaceEventInfo=NULL;          //racchiude le info dell'event
    QGroupBox *spaceEventModal=NULL;         //racchiude il modal dell'event
    QGroupBox *spaceEventAdd=NULL;          //racchiude l'add dell'event
    QGroupBox *spaceToDoAdd=NULL;           //racchiude l'add del toDo
    QGroupBox *spaceCalendarAdd=NULL;       //racchiude l'add di un calendario
    QGroupBox *spaceCalendarShare=NULL;     //racchiude la share di un calendario
    QGroupBox *spaceCalendarDelete=NULL;    //racchiude la delete di un calendario
    QGroupBox *spaceTextEditTask=NULL;
    QGroupBox *spaceTextEditToDo=NULL;
    QGroupBox *spaceCalendarButtons=NULL;

    //campi della modifica task
    QTextEdit *teEdit;          //titolo
    QTextEdit *dEdit;           //data
    QTextEdit *oraInizioEdit;
    QTextEdit *oraFineEdit;

    //campi di aggiunta task
    QTextEdit *editNomeE;       //titolo
    QTextEdit *editDataI;       //ora inizio
    QTextEdit *editDataF;       //ora fine
    QTextEdit *editData;        //YYYY-MM-DD

    //campi aggiunta toDo
    QTextEdit *nomeToDo;

    //campi modifica toDo
    QTextEdit *toDoEditName;

    //campi aggiunta calendario
    QTextEdit *nomeCal;

    //campi share calendario
    QTextEdit *email;



private:
    Ui::MainWindow *ui;

public slots:
    void addNewCalendar();
    void addNewCalendarSlot();
    void hideNewCalendar();
    void hideShareCalendar();
    void hideDeleteCalendar();
    void removeCalendar();
    void removeCalendarSlot();
    void shareCalendar();
    void shareCalendarSlot();
    void hideNewToDo();
    void hideAddTask();
    void hideModalEvent();
    void hideModalToDo();
    void refreshCalendar(Calendar*);
    void refreshEvents(Event*);
    void refreshEventss(int index);               //attivata al cambio di un calendario
    void refreshToDo(Event*);
    void modToDo();
    void addNewToDo();
    void addNewToDoSlot();
    void nascondiInfo();
    void nascondiInfoToDo();
    void addNewTask();
    void addNewTaskSlot();
    void updateTask();
    void updateToDo();
    void bau();
    void deleteToDo();
    void deleteEvent();
    void openNewWindow();
    void showPreferences();
    void hidePreferences();
    void miao();
    void getEventsByDay();
    void getToDos();
    void showCalendars(std::vector<Calendar *> ret);
    void showEvents(std::vector<Event *> ret);
    void showToDos(std::vector<Event *> ret);
    void selectEventTitle(int index);
    void impostaNomeTodo(int index);
    void selectCalendarTitle(int index);

private slots:                                  //quasi tutti i privati hanno a che fare con le preferenze calendario
    void localeChanged(int index);
    void firstDayChanged(int index);
    void selectionModeChanged(int index);
    void horizontalHeaderChanged(int index);
    void verticalHeaderChanged(int index);
    void selectedDateChanged();
    void minimumDateChanged(QDate date);
    void maximumDateChanged(QDate date);
    void weekdayFormatChanged();
    void weekendFormatChanged();
    void reformatHeaders();
    void reformatCalendarPage();
    void on_mMyButton_clicked();

signals:                                      //mi sa che questi signals non vengono mai usati
    void toMyNet();
    void makeGetGreatAgain();

private:

    int checkTime();
    int checkTimeUpdate();

    void deleteTutteCose();
    void modal();
    void modalToDo();
    void createCalendarButtons();

    void createPreviewGroupBox();
    void createTextFormatsGroupBox();
    void createGeneralOptionsGroupBox();
    QComboBox *createColorComboBox();
    QGroupBox *previewGroupBox;
    QGridLayout *previewLayout;
    QDateEdit *currentDateEdit;
    QLabel *localeLabel;
    QLabel *firstDayLabel;
    QLabel *selectionModeLabel;
    QLabel *horizontalHeaderLabel;
    QLabel *verticalHeaderLabel;
    QComboBox *localeCombo;
    QComboBox *firstDayCombo;

    QComboBox *calendarList;
    QComboBox *eventList;
    QComboBox *toDoList;

    QComboBox *selectionModeCombo;
    QCheckBox *gridCheckBox;
    QCheckBox *navigationCheckBox;
    QComboBox *horizontalHeaderCombo;
    QComboBox *verticalHeaderCombo;
    QGroupBox *generalOptionsGroupBox;
    QGroupBox *datesGroupBox;
    QLabel *currentDateLabel;
    QLabel *minimumDateLabel;
    QLabel *maximumDateLabel;
    QDateEdit *minimumDateEdit;
    QDateEdit *maximumDateEdit;
    QGroupBox *textFormatsGroupBox;
    QLabel *weekdayColorLabel;
    QLabel *weekendColorLabel;
    QLabel *headerTextFormatLabel;
    QComboBox *weekdayColorCombo;
    QComboBox *weekendColorCombo;
    QComboBox *headerTextFormatCombo;
    QCheckBox *firstFridayCheckBox;
    QCheckBox *mayFirstCheckBox;
};

#endif
