#ifndef API_H
#define API_H

#include <curl/curl.h>
#include <curlpp/cURLpp.hpp>
#include <curlpp/Easy.hpp>
#include <curlpp/Options.hpp>
#include <sstream> //per ostringstream
#include <vector>
#include "network.h"
#include "parser.h"
#include <QObject>
#include <iostream>
#include <mutex>
#include <condition_variable>
#include <thread>
#include <QThread>

using namespace curlpp::options;

/*
Basata su singleton. Alla prima costruzione si fa la post per ottenere i valori (auth code, ecc)

Pattern State per capire quale signal emettere una volta arrivata la risposta da network

TODO: - distruttore
*/


class API : public QObject {
    Q_OBJECT
public:
    //alla prima chiamata di getInstance dovrò passare t_code per la post nel costruttore, alle altre non passo niente
    static API* getInstance(std::string t_code="");

    /* Funzioni sui calendari */

    void getCalendars(); //senza parametri perché l'utente si capisce con l'auth code nella richiesta
    void insertCalendar(std::string summary); //summary è il titolo
    void deleteCalendar(std::string calendar_id);
    void shareCalendar(std::string calendar_id, std::string user_email);

    /* Funzioni sugli eventi */

    void getEventsByCalendarDay(std::string calendar_id, std::string dateMin, std::string dateMax);
    //il formato di date deve essere del tipo "2021-12-28T00:00:01Z"

    void insertEvent(std::string calendar_id, std::string summary, std::string begin_date, std::string end_date);
    //il formato di date deve essere del tipo "2021-12-28T00:00:01+01:00", con data variabile ma dal + in poi fisso

    void updateEvent(std::string calendar_id, std::string event_id, std::string new_summary, std::string start_date, std::string end_date);
    //il formato di date deve essere del tipo "2021-12-28T00:00:01+01:00", con data variabile ma dal + in poi fisso

    void deleteEvent(std::string calendar_id, std::string event_id);

    /* Funzioni sui ToDo */

    void getToDos(std::string calendar_id);
    void insertToDo(std::string calendar_id, std::string summary);
    void updateToDo(std::string calendar_id, std::string event_id, std::string new_summary);
    void deleteToDo(std::string calendar_id, std::string event_id);

    void getToDoEvents(std::string calendar_id,std::string dateMin,std::string dateMax);

    /*
Gli slot catturano i signal emessi da network e a loro volta emettono signal che verranno
presi dai componenti della gui
*/
public slots:
    void responseSlot(std::string response);
    void refreshTokenSlot();

    /*
I signal emessi da API verranno presi dalla gui per mostrare a schermo i risultati
*/
signals:
    //fare un signal per ogni valore della enum ResultType
    void signalCalendar(Calendar* calendar);
    void signalCalendarList(std::vector<Calendar*> calendarList);
    void signalEvent(Event* event);
    void signalEventList(std::vector<Event*> eventList);
    void signalToDoList(std::vector<Event*> eventList);
    void signalToDo(Event* event);
    void signalToDoListEventList(std::pair<std::vector<Event*>,std::vector<Event*>> ); //pair.first=todos, pair.second=events
    void signalEventDeleted(Event* event);      //saranno parametri vuoti perchè non mi servono
    void signalToDoDeleted(Event* event);       //stesso di sopra
    void signalCalendarDeleted(Calendar* c);    //per triggerare getCalendar() dopo l'eliminazione


private:
    static API *instance;

    enum ResultType {CALENDAR_LIST, CALENDAR, EVENT_LIST, EVENT, TODO_LIST, TODO, EMPTY, DELETE_EVENT, DELETE_TODO, DELETE_CALENDAR, REFRESH, TODOEVENTS_PARTIAL, TODOEVENTS_FINAL};
    ResultType resultType;

    std::string a_code;
    std::string r_token;
    std::string exp_in;
    Network *network;
    Parser *parser;

    std::vector<Event*> todos; //per tenere il risultato prima dell'invocazione di returnToDoListEventListFinal
    std::string dateMin; //simile a sopra
    std::string dateMax; //simile a sopra
    std::string calendar_id; //simile a sopra

    std::mutex m; //lock su a_code per gestire il refresh
    std::condition_variable cv; //usata dal thread per attendere finché non avrò ottenuto il nuovo exp_in

    API(std::string t_code,QObject *parent = 0); //costruttore privato


    std::vector<std::string> split(std::string s, std::string delimiter);
    void refreshToken(API* api);

    void returnCalendarList(std::string response);
    void returnCalendar(std::string response);
    void returnEventList(std::string response);
    void returnEvent(std::string response);
    void returnToDoList(std::string response);
    void returnToDo(std::string response);
    void refreshParams(std::string response);
    void returnEventDeleted();
    void returnToDoDeleted();
    void returnCalendarDeleted();

    void insertGenericEvent(std::string calendar_id,std::string summary,std::string description,std::string begin_date,std::string end_date);

    void returnToDoListEventListPartial(std::string response);
    void returnToDoListEventListFinal(std::string response);
};

class APIThread : public QThread {
    Q_OBJECT
public:
    void setCV(std::condition_variable *cv);
    void setM(std::mutex *m);
    void setExpIn(std::string *exp_in);
signals:
    void signalRefresh();
private:
    void run();
    std::mutex *m;
    std::condition_variable *cv;
    std::string *exp_in;
};


#endif // API_H
